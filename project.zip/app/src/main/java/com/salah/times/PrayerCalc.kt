package com.salah.times

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

data class City(val name: String, val lat: Double, val lon: Double)

val CITIES = listOf(
    City("Cairo", 30.0444, 31.2357),
    City("Giza", 29.987, 31.2118),
    City("Alexandria", 31.2001, 29.9187),
    City("Port Said", 31.2653, 32.3019),
    City("Suez", 29.9668, 32.5498),
    City("Mansoura", 31.0409, 31.3785),
    City("Tanta", 30.7865, 31.0004),
    City("Luxor", 25.6872, 32.6396),
    City("Aswan", 24.0889, 32.8998),
    City("Hurghada", 27.2579, 33.8116)
)

val PRAYERS = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
val PRAYERS_AR = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

val HIJRI_EN = listOf(
    "Muharram", "Safar", "Rabi I", "Rabi II", "Jumada I", "Jumada II",
    "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhu al-Qadah", "Dhu al-Hijjah"
)
val HIJRI_AR = listOf(
    "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
)

val ZONE: ZoneId = ZoneId.of("Africa/Cairo")

object PrayerCalc {
    // Egyptian General Authority of Survey: Fajr 19.5, Isha 17.5, standard Asr.
    fun times(date: LocalDate, city: City): List<Instant> {
        val n = date.dayOfYear
        val g = 2 * PI / 365 * (n - 1)
        val eqt = 229.18 * (0.000075 + 0.001868 * cos(g) - 0.032077 * sin(g) -
                0.014615 * cos(2 * g) - 0.040849 * sin(2 * g))
        val decl = 0.006918 - 0.399912 * cos(g) + 0.070257 * sin(g) - 0.006758 * cos(2 * g) +
                0.000907 * sin(2 * g) - 0.002697 * cos(3 * g) + 0.00148 * sin(3 * g)
        val lat = Math.toRadians(city.lat)
        val noon = 12.0 - city.lon / 15.0 - eqt / 60.0

        fun ha(ang: Double): Double {
            var c = (sin(Math.toRadians(ang)) - sin(lat) * sin(decl)) / (cos(lat) * cos(decl))
            c = c.coerceIn(-1.0, 1.0)
            return Math.toDegrees(acos(c)) / 15.0
        }

        val asrAlt = Math.toDegrees(atan(1.0 / (1.0 + tan(abs(lat - decl)))))
        val hrs = listOf(
            noon - ha(-19.5),
            noon,
            noon + ha(asrAlt),
            noon + ha(-0.833) - 1.0 / 60.0,
            noon + ha(-17.5)
        )
        val base = date.atStartOfDay(ZoneOffset.UTC).toInstant()
        return hrs.map { base.plusSeconds(Math.round(it * 60.0) * 60L) }
    }
}
