package com.salah.times

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.LocalDate

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("salah", Context.MODE_PRIVATE)
    fun city(c: Context): Int = sp(c).getInt("city", 0).coerceIn(0, CITIES.size - 1)
    fun setCity(c: Context, v: Int) { sp(c).edit().putInt("city", v).apply() }
    fun pre(c: Context): Boolean = sp(c).getBoolean("pre", true)
    fun setPre(c: Context, v: Boolean) { sp(c).edit().putBoolean("pre", v).apply() }
    fun azan(c: Context): Boolean = sp(c).getBoolean("azan", true)
    fun setAzan(c: Context, v: Boolean) { sp(c).edit().putBoolean("azan", v).apply() }
}

data class Ev(val at: Instant, val idx: Int, val pre: Boolean)

object Scheduler {
    fun nextPrayer(city: City, now: Instant): Pair<Instant, Int>? {
        val today = LocalDate.now(ZONE)
        for (d in 0L..2L) {
            val t = PrayerCalc.times(today.plusDays(d), city)
            for (i in t.indices) {
                if (t[i].isAfter(now)) return Pair(t[i], i)
            }
        }
        return null
    }

    fun nextEvent(ctx: Context): Ev? {
        val city = CITIES[Prefs.city(ctx)]
        val now = Instant.now().plusSeconds(2)
        val today = LocalDate.now(ZONE)
        val list = ArrayList<Ev>()
        for (d in 0L..2L) {
            val t = PrayerCalc.times(today.plusDays(d), city)
            for (i in t.indices) {
                if (Prefs.pre(ctx)) list.add(Ev(t[i].minusSeconds(300), i, true))
                list.add(Ev(t[i], i, false))
            }
        }
        return list.filter { it.at.isAfter(now) }.minByOrNull { it.at }
    }

    fun scheduleNext(ctx: Context) {
        val ev = nextEvent(ctx) ?: return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, AlarmReceiver::class.java)
        intent.putExtra("idx", ev.idx)
        intent.putExtra("pre", ev.pre)
        val pi = PendingIntent.getBroadcast(
            ctx, 1, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val ms = ev.at.toEpochMilli()
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }
}
