package com.salah.times

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val idx = intent.getIntExtra("idx", 0).coerceIn(0, 4)
        val pre = intent.getBooleanExtra("pre", false)
        Notifier.ensureChannels(ctx)
        if (pre) {
            Notifier.show(ctx, 200 + idx, Notifier.CH_PRE, "${PRAYERS[idx]} prayer in 5 minutes", PRAYERS_AR[idx])
        } else if (Prefs.azan(ctx)) {
            try {
                ctx.startForegroundService(Intent(ctx, AzanService::class.java).putExtra("idx", idx))
            } catch (e: Exception) {
                Notifier.show(ctx, 100 + idx, Notifier.CH_AT, "${PRAYERS[idx]} prayer", PRAYERS_AR[idx])
            }
        } else {
            Notifier.show(ctx, 100 + idx, Notifier.CH_AT, "${PRAYERS[idx]} prayer", PRAYERS_AR[idx])
        }
        Scheduler.scheduleNext(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleNext(ctx)
    }
}
