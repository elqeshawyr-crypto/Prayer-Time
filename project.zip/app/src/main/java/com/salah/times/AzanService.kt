package com.salah.times

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class AzanService : Service() {
    private var player: MediaPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val idx = (intent?.getIntExtra("idx", 0) ?: 0).coerceIn(0, 4)
        Notifier.ensureChannels(this)
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, AzanService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notifier.builder(this, Notifier.CH_AZAN, "${PRAYERS[idx]} prayer", PRAYERS_AR[idx])
            .setOngoing(true)
            .addAction(R.drawable.ic_notif, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(7, n)
        }
        try {
            player?.release()
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            val afd = resources.openRawResourceFd(R.raw.azan)
            p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            p.setOnCompletionListener { stopSelf() }
            p.prepare()
            p.start()
            player = p
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
