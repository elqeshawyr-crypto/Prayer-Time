package com.salah.times

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoField
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val acc = Color.parseColor("#0E6B63")
    private val ink = Color.parseColor("#14232B")
    private val faint = Color.parseColor("#8A9AA2")
    private lateinit var hijri: TextView
    private lateinit var nextName: TextView
    private lateinit var countdown: TextView
    private lateinit var nextAt: TextView
    private val nameViews = ArrayList<TextView>()
    private val timeViews = ArrayList<TextView>()
    private val fmt = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int = ink, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(top)
        return p
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Notifier.ensureChannels(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#F1F5F7"))
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(36), dp(16), dp(32))
        scroll.addView(root)

        root.addView(tv("Salah Times", 22f, bold = true))
        hijri = tv("", 14f, Color.parseColor("#5A6B74"))
        root.addView(hijri)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundColor(acc)
        card.setPadding(dp(20), dp(18), dp(20), dp(18))
        card.addView(tv("NEXT PRAYER", 12f, Color.WHITE))
        nextName = tv("", 26f, Color.WHITE, true)
        card.addView(nextName)
        countdown = tv("", 40f, Color.WHITE)
        card.addView(countdown)
        nextAt = tv("", 14f, Color.WHITE)
        card.addView(nextAt)
        root.addView(card, lp(16))

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setBackgroundColor(Color.WHITE)
        list.setPadding(dp(16), dp(6), dp(16), dp(6))
        for (i in 0..4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, dp(12), 0, dp(12))
            val n = tv("${PRAYERS[i]}   ${PRAYERS_AR[i]}", 17f)
            val t = tv("", 17f)
            t.gravity = Gravity.END
            row.addView(n, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            list.addView(row)
            nameViews.add(n)
            timeViews.add(t)
        }
        root.addView(list, lp(16))

        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, CITIES.map { it.name })
        sp.setSelection(Prefs.city(this))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != Prefs.city(this@MainActivity)) {
                    Prefs.setCity(this@MainActivity, pos)
                    Scheduler.scheduleNext(this@MainActivity)
                    refresh()
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sp, lp(16))

        val s1 = Switch(this)
        s1.text = "Notify 5 minutes before each prayer"
        s1.isChecked = Prefs.pre(this)
        s1.setOnCheckedChangeListener { _, c ->
            Prefs.setPre(this, c)
            Scheduler.scheduleNext(this)
        }
        root.addView(s1, lp(12))

        val s2 = Switch(this)
        s2.text = "Play azan at prayer time"
        s2.isChecked = Prefs.azan(this)
        s2.setOnCheckedChangeListener { _, c -> Prefs.setAzan(this, c) }
        root.addView(s2, lp(12))

        val test = Button(this)
        test.text = "Test azan"
        test.setOnClickListener {
            startForegroundService(Intent(this, AzanService::class.java).putExtra("idx", 0))
        }
        root.addView(test, lp(16))

        val stop = Button(this)
        stop.text = "Stop azan"
        stop.setOnClickListener {
            startService(Intent(this, AzanService::class.java).setAction("STOP"))
        }
        root.addView(stop, lp(0))

        val batt = Button(this)
        batt.text = "Allow background running"
        batt.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
            }
        }
        root.addView(batt, lp(0))

        val note = tv(
            "On Samsung: Settings > Battery > Background usage limits, make sure Salah Times is not in " +
                "Sleeping apps, and set its battery to Unrestricted.",
            13f, Color.parseColor("#5A6B74")
        )
        root.addView(note, lp(12))

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleNext(this)
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun refresh() {
        val now = Instant.now()
        val city = CITIES[Prefs.city(this)]
        val today = LocalDate.now(ZONE)
        val t = PrayerCalc.times(today, city)
        val nx = Scheduler.nextPrayer(city, now)
        for (i in 0..4) {
            timeViews[i].text = fmt.format(t[i].atZone(ZONE))
            val isNext = nx != null && nx.first == t[i]
            val style = if (isNext) Typeface.BOLD else Typeface.NORMAL
            nameViews[i].setTypeface(null, style)
            timeViews[i].setTypeface(null, style)
            val c = if (isNext) acc else if (t[i].isBefore(now)) faint else ink
            nameViews[i].setTextColor(c)
            timeViews[i].setTextColor(c)
        }
        if (nx != null) {
            val s = Duration.between(now, nx.first).seconds.coerceAtLeast(0L)
            nextName.text = "${PRAYERS[nx.second]}  ${PRAYERS_AR[nx.second]}"
            countdown.text = String.format(Locale.ENGLISH, "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
            nextAt.text = "at " + fmt.format(nx.first.atZone(ZONE)) + " in " + city.name
        }
        hijri.text = hijriText(today, t[3].isBefore(now))
    }

    private fun hijriText(d: LocalDate, afterMaghrib: Boolean): String {
        return try {
            val h = HijrahDate.from(if (afterMaghrib) d.plusDays(1) else d)
            val day = h.get(ChronoField.DAY_OF_MONTH)
            val m = h.get(ChronoField.MONTH_OF_YEAR)
            val y = h.get(ChronoField.YEAR)
            "$day ${HIJRI_EN[m - 1]} $y AH   |   $day ${HIJRI_AR[m - 1]} $y"
        } catch (e: Exception) {
            ""
        }
    }
}
